public class ConsCell {
	int x;
	int y;
	ConsCell tail;
	
	public ConsCell(int i, int j, ConsCell t) {
		x = i;
		y = j;
		tail = t;
	}
	
	public ConsCell getTail() {
		return tail;
	}

	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}	
	
}