public class CoordList {
	ConsCell start;
	
	public CoordList(ConsCell s) {
		start = s;
	}
	
	public CoordList cons (int x, int y) {
		return new CoordList(new ConsCell(x, y, start));
	}
	
}