import java.io.*;

public class Moredeli {	
	public static void main (String[] args) {
		File f = null;
		int i = 0, j = 0, start_i = 0, start_j = 0, end_i = 0, end_j = 0, M = 0, N = 0;
		Space[][] map = new Space[1000][1000]; 
		if (args.length == 1) f = new File(args[0]);
		else {
			System.err.println("Wrong number of parameters.");
			System.exit(21);
		}	
		BufferedReader freader = null;
        try {
            int r;
            freader = new BufferedReader(new FileReader(f));						/* read file and store map in object map of class Space */
            while ((r = freader.read()) != -1) {									/* M has number of columns (max 1000) and N number of rows (max 1000)*/
				char ch = (char) r;
				if(ch == 'S') {
					start_i = i;
					start_j = j;
				}
				if(ch == 'E') {
					end_i = i;
					end_j = j;
				}
				if(ch == '\n') {
					M = j;
					j = 0;
					i++;
				}
				else {
					map[i][j] = new Space(ch, -1);
					j++;
				}
            }
			N = i;
        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        finally {
            try {
                if (freader != null) freader.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
		map[start_i][start_j].distance1 = 0;

		CoordList a = new CoordList(null);											/* we create a queue with all possible neighbours, that we refresh */
		CoordList fifo = a.cons(start_i, start_j);									/* queue has only coordinates of S at the begining  */
		CoordList temp = new CoordList(null);										/* temp has the new list that will replace fifo */
		do {
			temp = new CoordList(null);
			while(fifo.start != null) {												
				if((fifo.start.x - 1) >= 0 && map[fifo.start.x - 1][fifo.start.y].symbol != 'X') {				/* check upper box */
					if(map[fifo.start.x - 1][fifo.start.y].distance1 > (map[fifo.start.x][fifo.start.y].distance1 + 3) || map[fifo.start.x - 1][fifo.start.y].distance1 == -1) {
						map[fifo.start.x - 1][fifo.start.y].distance1 = map[fifo.start.x][fifo.start.y].distance1 + 3;
						temp = temp.cons(fifo.start.x - 1, fifo.start.y);
					}
				}
				if((fifo.start.x + 1) < N && map[fifo.start.x + 1][fifo.start.y].symbol != 'X') {				/* check lower box */
					if(map[fifo.start.x + 1][fifo.start.y].distance1 > (map[fifo.start.x][fifo.start.y].distance1 + 1) || map[fifo.start.x + 1][fifo.start.y].distance1 == -1) {
						map[fifo.start.x + 1][fifo.start.y].distance1 = map[fifo.start.x][fifo.start.y].distance1 + 1;
						temp = temp.cons(fifo.start.x + 1, fifo.start.y);
					}					
				}
				if((fifo.start.y - 1) >= 0 && map[fifo.start.x][fifo.start.y - 1].symbol != 'X') {				/* check left box */
					if(map[fifo.start.x][fifo.start.y - 1].distance1 > (map[fifo.start.x][fifo.start.y].distance1 + 2) || map[fifo.start.x][fifo.start.y - 1].distance1 == -1) {
						map[fifo.start.x][fifo.start.y - 1].distance1 = map[fifo.start.x][fifo.start.y].distance1 + 2;
						temp = temp.cons(fifo.start.x, fifo.start.y - 1);
					}
				}
				if((fifo.start.y + 1) < M && map[fifo.start.x][fifo.start.y + 1].symbol != 'X') {				/* check right box */
					if(map[fifo.start.x][fifo.start.y + 1].distance1 > (map[fifo.start.x][fifo.start.y].distance1 + 1) || map[fifo.start.x][fifo.start.y + 1].distance1 == -1) {
						map[fifo.start.x][fifo.start.y + 1].distance1 = map[fifo.start.x][fifo.start.y].distance1 + 1;
						temp = temp.cons(fifo.start.x, fifo.start.y + 1);
					}
				}				
				fifo.start = fifo.start.getTail();
			}
			fifo.start = temp.start;												/* replace fifo with new list of neighbours */
		} while(fifo.start != null);

		System.out.print("" + map[end_i][end_j].distance1 + " ");
		int d = map[end_i][end_j].distance1;
		char[] route = new char[1000000];
		int k = 0;
		int is = end_i;
		int js = end_j;
		route[k++] = '\n';
		while(d > 0) {
			if((is - 1) >= 0 && map[is - 1][js].symbol != 'X' && map[is - 1][js].distance1 == (map[is][js].distance1 - 1)) {
				route[k] = 'D';
				d--;
				is--;
				k++;
			}
			else if((is + 1) < N && map[is + 1][js].symbol != 'X' && map[is + 1][js].distance1 == (map[is][js].distance1 - 3)) {
				route[k] = 'U';
				d = d - 3;
				is++;
				k++;				
			}
			else if((js - 1) >= 0 && map[is][js - 1].symbol != 'X' && map[is][js - 1].distance1 == (map[is][js].distance1 - 1)) {
				route[k] = 'R';
				d--;
				js--;
				k++;
			}
			if((js + 1) < M && map[is][js + 1].symbol != 'X' && map[is][js + 1].distance1 == (map[is][js].distance1 - 2)) {
				route[k] = 'L';
				d = d - 2;
				js++;
				k++;
			}			
		}
		for(i = k - 1; i >= 0 ; i--) System.out.print(route[i]);
	}
}