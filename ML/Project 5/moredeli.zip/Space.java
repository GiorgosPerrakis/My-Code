public class Space {
	char symbol;
	int distance1;
	
	public Space(char s, int d1) {
		symbol = s;
		distance1 = d1;
	}
}